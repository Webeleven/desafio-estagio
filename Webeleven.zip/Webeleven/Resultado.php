<?php
  //criar classe p Calculadora
  class Calculadora {

      public function Calcular() {

        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];
        $op= $_POST['operacao'];

        switch ($op) {
          case '+':
            $result=$num1+$num2;
            break;
          case '-':
            $result=$num1-$num2;
            break;
          case '*':
            $result=$num1*$num2;
            break;
          case '/':
            $result=$num1/$num2;
            break;

          default:
            echo "opção invalida";
            break;
        }
        $result=('O resultado é "'.$result.'"');
        return $result;
      }
    }
          # Instancia a classe CALCULADORA()
       $calcular = new Calculadora();

        # Executa a função
       echo $calcular->Calcular();
?>
<form>
  <p>
<input type="button" value="Voltar" onClick="JavaScript: window.history.back();">
</form>
