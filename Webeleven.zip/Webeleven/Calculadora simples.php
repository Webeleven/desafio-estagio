<!DOCTYPE HTML>
<html>
<head>
    <!-- Exercício de calculadora simples para WebEleven-->
   <title>Calculadora simples</title>
   <meta charset = "UTF-8">
</head>
<body>
   <form action="Resultado.php" method="post" >
      Primeiro Numero: <input name="num1" type="text"><br>
      Segundo numero:  <input name="num2" type="text"><br>
      <select name=operacao>
       <option value="+">+</option>
       <option value="-">-</option>
       <option value="/">/</option>
       <option value="*">*</option>
      </select>
      <p>
        <input type="submit" value="Calcular">
    </form>


</body>
</html>
